package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class LoginActivity extends AppCompatActivity {
    //initialize the following pages and button
    //TabLayout tabLayout;
    Button loginButton, signupButton;
    ViewPager viewPager;
    FloatingActionButton facebook,google,twitter;
    float p=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_tab_fragment);

//        loginButton = findViewById(R.id.loginButton);
//        loginButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openLoginPage();
//            }
//        });
//
//        signupButton = findViewById(R.id.signupButton);
//        signupButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openSignUpPage();
//            }
//        });

        //bind to corresponding views
        viewPager = findViewById(R.id.viewPager);
        facebook = findViewById(R.id.fbLogos);
        google = findViewById(R.id.googleLogos);
        twitter = findViewById(R.id.twtLogos);

        //add tabs in tablayout 1:login and 2.signup

        //object of login adapter
//    final LoginAdapter loginAdapter = new LoginAdapter(getSupportFragmentManager(), this, tabLayout.getTabCount());
//        viewPager.setAdapter(loginAdapter);
//
//    viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        facebook.setTranslationY(300);
        google.setTranslationY(300);
        twitter.setTranslationY(300);


        facebook.setAlpha(p);
        google.setAlpha(p);
        twitter.setAlpha(p);


        facebook.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(400).start();
        google.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(600).start();
        twitter.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(800).start();

        DBHelper database = new DBHelper(this);

    }
//    public void openLoginPage() {
//        Intent intent = new Intent(this, LoginTabFragment.class);
//        startActivity(intent);
//    }
//    public void openSignUpPage() {
//        Intent intent = new Intent(this, SignupTabFragment.class);
//        startActivity(intent);
//    }



}