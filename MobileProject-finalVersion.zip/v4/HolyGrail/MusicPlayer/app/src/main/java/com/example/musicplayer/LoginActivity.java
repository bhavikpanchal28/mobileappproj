package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class LoginActivity extends AppCompatActivity {
    //initialize the following pages and button
    ViewPager viewPager;
    FloatingActionButton facebook,google,twitter;
    Button button;
    float p=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //bind to corresponding views
        viewPager = findViewById(R.id.viewPager);
        facebook = findViewById(R.id.fbLogos);
        google = findViewById(R.id.googleLogos);
        twitter = findViewById(R.id.twtLogos);



         facebook.setTranslationY(300);
        google.setTranslationY(300);
        twitter.setTranslationY(300);

        facebook.setAlpha(p);
        google.setAlpha(p);
        twitter.setAlpha(p);


        facebook.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(400).start();
        google.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(600).start();
        twitter.animate().translationY(0).alpha(1).setDuration(1000).setStartDelay(800).start();

        DBHelper database = new DBHelper(this);

    }
}