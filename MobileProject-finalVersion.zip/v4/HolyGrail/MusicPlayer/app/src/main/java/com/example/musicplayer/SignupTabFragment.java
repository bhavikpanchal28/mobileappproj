package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupTabFragment extends AppCompatActivity{
    EditText username,email, password, conpassword;
    Button signup, loginButton;
    float p=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_tab_fragment);

        //initialize the objects
        username = findViewById(R.id.username1);
        email = findViewById(R.id.email1);
        password = findViewById(R.id.password1);
        conpassword = findViewById(R.id.confirmpass);
        signup = findViewById(R.id.signup);
        loginButton = findViewById(R.id.loginButton);

        username.setTranslationX(800);
        email.setTranslationX(800);
        password.setTranslationX(800);
        conpassword.setTranslationX(800);
        signup.setTranslationX(800);

        username.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        email.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        password.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        conpassword.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        signup.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();

        //declaring functionality of login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin();
            }
        });
        //declaring functionality of sign up button
        signup.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override

            public void onClick(View view) {
                DBHelper database = new DBHelper(getBaseContext());
                String usernameText = username.getText().toString();
                String passwordText = password.getText().toString();
                String emailText = email.getText().toString();
                String conpasswordText = conpassword.getText().toString();
                Toast myToast;

                if (usernameText.equals("") || passwordText.equals("") || emailText.equals("") || conpasswordText.equals("")) {
                    myToast = Toast.makeText(getBaseContext(), "Empty Field(s) found. Try Again.", Toast.LENGTH_SHORT);
                } else if (database.checkUser(usernameText) || database.checkEmail(emailText)) {
                    myToast = Toast.makeText(getBaseContext(), "Username or Email taken. Try Again.", Toast.LENGTH_SHORT);
                } else if (passwordText.length() < 5) {
                    myToast = Toast.makeText(getBaseContext(), "Password is too short. Try Again.", Toast.LENGTH_SHORT);
                } else if (!(passwordText.equals(conpasswordText))) {
                    myToast = Toast.makeText(getBaseContext(), "Passwords do no match. Try Again.", Toast.LENGTH_SHORT);
                } else {
                    database.insertAccount(usernameText, emailText, passwordText);
                    username.setText("");
                    email.setText("");
                    password.setText("");
                    conpassword.setText("");
                    myToast = Toast.makeText(getBaseContext(), "Sign up successful.", Toast.LENGTH_SHORT);
                    openLogin();
                }
                myToast.show();
            }

        });
    }
    //intent for returning users to access login page, if they already have an account
    public void openLogin(){
        Intent intent = new Intent(this, LoginTabFragment.class);
        startActivity(intent);
    }
}
