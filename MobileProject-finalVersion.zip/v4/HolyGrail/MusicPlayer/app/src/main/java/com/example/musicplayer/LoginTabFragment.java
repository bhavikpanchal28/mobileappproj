package com.example.musicplayer;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class LoginTabFragment extends AppCompatActivity{
    Button login, signupButton;

    EditText email, username, password;

    TextView forgetpassword;
    float p=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_tab_fragment);

        //bind to corresponding views
        email = findViewById(R.id.username1);
        password = findViewById(R.id.password);
        username = findViewById(R.id.username1);
        forgetpassword = findViewById(R.id.forgetpassword);
        login = findViewById(R.id.button);
        signupButton = findViewById(R.id.signupButton);

        username.setTranslationX(800);
        email.setTranslationX(800);
        password.setTranslationX(800);
        forgetpassword.setTranslationX(800);
        login.setTranslationX(800);

        email.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(300).start();
        password.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        forgetpassword.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(500).start();
        login.animate().translationX(0).alpha(1).setDuration(800).setStartDelay(700).start();


        signupButton.setOnClickListener(v -> {
            openSignUpPage();

        });


        login.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override

            public void onClick(View view) {

                DBHelper database = new DBHelper(getBaseContext());
                String usernameText = username.getText().toString();
                String passwordText = password.getText().toString();

                boolean checker = database.checkLogin(usernameText,passwordText);
                Toast myToast;
                if (checker) {
                    //Move to MainActivity from here
                    openMainActivity();
                }
                else {
                    myToast = Toast.makeText(getBaseContext(), "Log in error. Try Again.", Toast.LENGTH_SHORT);
                    myToast.show();
                }
            }
        });

    }
    //intent to direct user to the sign up page
    public void openSignUpPage() {
        Intent intent = new Intent(this, SignupTabFragment.class);
        startActivity(intent);
    }
    //intent to direct user to main page containing users files after user has logged in correctly
    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
